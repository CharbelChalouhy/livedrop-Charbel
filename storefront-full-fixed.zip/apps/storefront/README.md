# Storefront App

Run `pnpm install` and `pnpm dev` to start the development server.